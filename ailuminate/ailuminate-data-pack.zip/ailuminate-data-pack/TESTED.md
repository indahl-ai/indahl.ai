# AILUMINATE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-26 16:20 UTC and checked against the live feed at https://indahl.ai/ailuminate/live.json.

- holds: ailuminate_summary.csv: 64 rows, one per value of the live feed (64)
- holds: ailuminate_outcomes.csv: 2 rows, the live feed holds 2 results, outcome, n, lo and hi equal on every row
- holds: page headline "0 of 27": 0 is in the pack
- holds: page headline "0 of 27": 27 is in the pack

TESTED 2026-11-26 16:20 UTC: 4 checks, every one holds.
