# AIRQ Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-23 03:14 UTC and checked against the live feed at https://indahl.ai/airq/live.json.

- holds: airq_summary.csv: 161 rows, one per value of the live feed (161)
- holds: airq_outcomes.csv: 9 rows, the live feed holds 9 results, outcome, n, lo and hi equal on every row
- holds: page headline "52 of 60": 52 is in the pack
- holds: page headline "52 of 60": 60 is in the pack

TESTED 2026-11-23 03:14 UTC: 4 checks, every one holds.
