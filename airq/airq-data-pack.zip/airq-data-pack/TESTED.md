# AIRQ Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-26 10:48 UTC and checked against the live feed at https://indahl.ai/airq/live.json.

- holds: airq_summary.csv: 160 rows, one per value of the live feed (160)
- holds: airq_outcomes.csv: 9 rows, the live feed holds 9 results, outcome, n, lo and hi equal on every row
- holds: page headline "55 of 62": 55 is in the pack
- holds: page headline "55 of 62": 62 is in the pack

TESTED 2026-11-26 10:48 UTC: 4 checks, every one holds.
