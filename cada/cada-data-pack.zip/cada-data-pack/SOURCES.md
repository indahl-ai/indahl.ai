# CADA Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 19 Nov 2026 10:34, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Phishing.Database active domains | https://github.com/mitchellkrogza/Phishing.Database | MIT | 19 Nov 2026 10:34 |
| CERT Polska warning list | https://cert.pl/en/warning-list/ | CERT Polska terms | 19 Nov 2026 10:34 |
| Answers of public DNS resolvers | https://indahl.ai/cada | our own measurements | 19 Nov 2026 10:34 |
