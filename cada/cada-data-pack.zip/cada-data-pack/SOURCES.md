# CADA Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 23 Nov 2026 23:20, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Phishing.Database active domains | https://github.com/mitchellkrogza/Phishing.Database | MIT | 23 Nov 2026 23:20 |
| CERT Polska warning list | https://cert.pl/en/warning-list/ | CERT Polska terms | 23 Nov 2026 23:20 |
| Answers of public DNS resolvers | https://indahl.ai/cada | our own measurements | 23 Nov 2026 23:20 |
