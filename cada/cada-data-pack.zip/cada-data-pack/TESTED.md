# CADA Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-27 10:48 UTC and checked against the live feed at https://indahl.ai/cada/live.json.

- holds: cada_summary.csv: 245 rows, one per value of the live feed (245)
- holds: cada_outcomes.csv: 0 rows, the live feed holds 0 results, outcome, n, lo and hi equal on every row
- holds: cada_summary.json: byte for byte the live feed (sha256 79805efa70efd139)

TESTED 2026-11-27 10:48 UTC: 3 checks, every one holds.
