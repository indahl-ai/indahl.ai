# CADENCE Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 24 Nov 2026 13:47, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Federal agency data.json catalogues (DCAT-US) | https://resources.data.gov/resources/dcat-us/ | U.S. government work, public domain (17 U.S.C. 105) | 24 Nov 2026 13:47 |
