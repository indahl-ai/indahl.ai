# CADENCE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-28 19:01 UTC and checked against the live feed at https://indahl.ai/cadence/live.json.

- holds: cadence_summary.csv: 580 rows, one per value of the live feed (580)
- holds: cadence_outcomes.csv: 8 rows, the live feed holds 8 results, outcome, n, lo and hi equal on every row
- holds: cadence_summary.json: byte for byte the live feed (sha256 c8deb5232eaa6f48)
- holds: page headline "641 of 1,243": 641 is in the pack
- holds: page headline "641 of 1,243": 1,243 is in the pack

TESTED 2026-11-28 19:01 UTC: 5 checks, every one holds.
