# CADENCE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-28 17:05 UTC and checked against the live feed at https://indahl.ai/cadence/live.json.

- holds: cadence_summary.csv: 580 rows, one per value of the live feed (580)
- holds: cadence_outcomes.csv: 8 rows, the live feed holds 8 results, outcome, n, lo and hi equal on every row
- holds: cadence_summary.json: byte for byte the live feed (sha256 e7410c50a34c8af4)
- holds: page headline "641 of 1,243": 641 is in the pack
- holds: page headline "641 of 1,243": 1,243 is in the pack

TESTED 2026-11-28 17:05 UTC: 5 checks, every one holds.
