# CAMPUS Data Pack

Heuremen LLC · https://indahl.ai/campus

As of 28 Nov 2026 01:51, the time stamped on the desk's feed when this pack was built.

## The question

The documents behind the OY page, kept over time. The page states it in full at https://indahl.ai/campus.

## The ruler

The ruler and the outcome rules are stated on the page at https://indahl.ai/campus.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/campus_outcomes.csv holds 0 rows, each with an interval and no outcome word.

## Files

- results/campus_summary.json: the feed as served at https://indahl.ai/campus/live.json when this pack was built.
- results/campus_summary.csv: the same file flattened to one row per value, with its path.
- results/campus_outcomes.json and results/campus_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served, with credit to each source in NOTICE.txt.

## Cite

Heuremen LLC, OY Desk Packs, Zenodo, doi:10.5281/zenodo.24118628

https://doi.org/10.5281/zenodo.24118628

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
