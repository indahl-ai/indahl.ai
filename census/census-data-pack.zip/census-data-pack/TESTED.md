# CENSUS Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-23 04:34 UTC and checked against the live feed at https://indahl.ai/census/live.json.

- holds: census_summary.csv: 2537 rows, one per value of the live feed (2537)
- holds: census_outcomes.csv: 144 rows, the live feed holds 144 results, outcome, n, lo and hi equal on every row
- holds: census_summary.json: byte for byte the live feed (sha256 93fa7d2d69553989)
- holds: page headline "117 of 117": 117 is in the pack
- holds: page headline "117 of 117": 117 is in the pack
- holds: rows.csv: 5055 rows, the live feed counts 5055

TESTED 2026-11-23 04:34 UTC: 6 checks, every one holds.
