# CENSUS Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-27 06:49 UTC and checked against the live feed at https://indahl.ai/census/live.json.

- holds: census_summary.csv: 3181 rows, one per value of the live feed (3181)
- holds: census_outcomes.csv: 189 rows, the live feed holds 189 results, outcome, n, lo and hi equal on every row
- holds: census_summary.json: byte for byte the live feed (sha256 a6ab949a06fb9912)
- holds: page headline "118 of 118": 118 is in the pack
- holds: page headline "118 of 118": 118 is in the pack
- holds: rows.csv: 5070 rows, the live feed counts 5070

TESTED 2026-11-27 06:49 UTC: 6 checks, every one holds.
