# CHANGE Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 24 Nov 2026 21:47, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Anthropic deprecation page | https://platform.claude.com/docs/en/about-claude/model-deprecations | the vendor keeps its rights, dates and names quoted as facts | 24 Nov 2026 21:47 |
| OpenAI deprecation page | https://developers.openai.com/api/docs/deprecations | the vendor keeps its rights, dates and names quoted as facts | 24 Nov 2026 21:47 |
| Google deprecation page | https://ai.google.dev/gemini-api/docs/deprecations | the vendor keeps its rights, dates and names quoted as facts | 24 Nov 2026 21:47 |
| Cloudflare deprecation page | https://developers.cloudflare.com/deprecations/ | the vendor keeps its rights, dates and names quoted as facts | 24 Nov 2026 21:47 |
