# CHANGE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-21 01:27 UTC and checked against the live feed at https://indahl.ai/change/live.json.

- holds: change_summary.csv: 286 rows, one per value of the live feed (286)
- holds: change_outcomes.csv: 1 rows, the live feed holds 1 results, outcome, n, lo and hi equal on every row
- holds: page headline "10 of 33": 10 is in the pack
- holds: page headline "10 of 33": 33 is in the pack

TESTED 2026-11-21 01:27 UTC: 4 checks, every one holds.
