# FEDSEP Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 28 Nov 2026 01:52, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| FOMC Summary of Economic Projections | https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm | U.S. government work, public domain (17 U.S.C. 105) | 28 Nov 2026 01:52 |
| BEA NIPA tables | https://www.bea.gov/ | U.S. government work, public domain (17 U.S.C. 105) | 28 Nov 2026 01:52 |
| BLS unemployment rate LNS14000000 | https://www.bls.gov/ | U.S. government work, public domain (17 U.S.C. 105) | 28 Nov 2026 01:52 |
| Federal Reserve H.15 | https://www.federalreserve.gov/releases/h15/ | U.S. government work, public domain (17 U.S.C. 105) | 28 Nov 2026 01:52 |
