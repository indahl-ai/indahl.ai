# FLU Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-25 17:55 UTC and checked against the live feed at https://indahl.ai/flu/live.json.

- holds: flu_summary.csv: 7300 rows, one per value of the live feed (7300)
- holds: flu_outcomes.csv: 284 rows, the live feed holds 284 results, outcome, n, lo and hi equal on every row
- holds: flu_summary.json: byte for byte the live feed (sha256 c311a2519c995c42)
- holds: page headline "88.9%": 88.9% is in the pack

TESTED 2026-11-25 17:55 UTC: 4 checks, every one holds.
