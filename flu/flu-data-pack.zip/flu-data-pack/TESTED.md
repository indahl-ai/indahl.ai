# FLU Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-21 10:19 UTC and checked against the live feed at https://indahl.ai/flu/live.json.

- holds: flu_summary.csv: 7300 rows, one per value of the live feed (7300)
- holds: flu_outcomes.csv: 284 rows, the live feed holds 284 results, outcome, n, lo and hi equal on every row
- holds: flu_summary.json: byte for byte the live feed (sha256 5d992745764c2653)
- holds: page headline "16,837 of 18,968": 16,837 is in the pack
- holds: page headline "16,837 of 18,968": 18,968 is in the pack

TESTED 2026-11-21 10:19 UTC: 5 checks, every one holds.
