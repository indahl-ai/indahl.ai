# FLU Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-23 07:24 UTC and checked against the live feed at https://indahl.ai/flu/live.json.

- holds: flu_summary.csv: 7300 rows, one per value of the live feed (7300)
- holds: flu_outcomes.csv: 284 rows, the live feed holds 284 results, outcome, n, lo and hi equal on every row
- holds: flu_summary.json: byte for byte the live feed (sha256 eaceb0c574115f33)
- holds: page headline "88.8%": 88.8% is in the pack

TESTED 2026-11-23 07:24 UTC: 4 checks, every one holds.
