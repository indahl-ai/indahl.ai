# FORECAST Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 18 Nov 2026 21:23, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| National Weather Service API | https://www.weather.gov/documentation/services-web-api | U.S. government work, public domain (17 U.S.C. 105) | 18 Nov 2026 21:23 |
| Iowa Environmental Mesonet ASOS archive | https://mesonet.agron.iastate.edu/request/download.phtml | public archive of government airport reports | 18 Nov 2026 21:23 |
