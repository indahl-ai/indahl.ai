# FORECAST Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 26 Nov 2026 10:48, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| National Weather Service API | https://www.weather.gov/documentation/services-web-api | U.S. government work, public domain (17 U.S.C. 105) | 26 Nov 2026 10:48 |
| Iowa Environmental Mesonet ASOS archive | https://mesonet.agron.iastate.edu/request/download.phtml | public archive of government airport reports | 26 Nov 2026 10:48 |
