# FORECAST Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-28 18:34 UTC and checked against the live feed at https://indahl.ai/forecast/live.json.

- holds: forecast_summary.csv: 362 rows, one per value of the live feed (362)
- holds: forecast_outcomes.csv: 37 rows, the live feed holds 37 results, outcome, n, lo and hi equal on every row
- holds: forecast_summary.json: byte for byte the live feed (sha256 628139c3ef5cb537)

TESTED 2026-11-28 18:34 UTC: 3 checks, every one holds.
