# HFLICENSE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-28 14:01 UTC and checked against the live feed at https://indahl.ai/hflicense/live.json.

- holds: hflicense_summary.csv: 70 rows, one per value of the live feed (70)
- holds: hflicense_outcomes.csv: 4 rows, the live feed holds 4 results, outcome, n, lo and hi equal on every row
- holds: page headline "0 of 111": 0 is in the pack
- holds: page headline "0 of 111": 111 is in the pack

TESTED 2026-11-28 14:01 UTC: 4 checks, every one holds.
