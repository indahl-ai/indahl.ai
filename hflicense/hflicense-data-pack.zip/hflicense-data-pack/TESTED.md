# HFLICENSE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-26 20:48 UTC and checked against the live feed at https://indahl.ai/hflicense/live.json.

- holds: hflicense_summary.csv: 68 rows, one per value of the live feed (68)
- holds: hflicense_outcomes.csv: 4 rows, the live feed holds 4 results, outcome, n, lo and hi equal on every row
- holds: page headline "0 of 108": 0 is in the pack
- holds: page headline "0 of 108": 108 is in the pack

TESTED 2026-11-26 20:48 UTC: 4 checks, every one holds.
