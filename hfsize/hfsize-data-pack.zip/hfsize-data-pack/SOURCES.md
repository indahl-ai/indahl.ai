# HFSIZE Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 26 Nov 2026 19:52, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Hugging Face Hub API | https://huggingface.co/docs/hub/api | Hugging Face terms of service, https://huggingface.co/terms-of-service | 26 Nov 2026 19:52 |
