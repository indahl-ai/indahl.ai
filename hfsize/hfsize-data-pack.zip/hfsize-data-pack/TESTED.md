# HFSIZE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-24 11:16 UTC and checked against the live feed at https://indahl.ai/hfsize/live.json.

- holds: hfsize_summary.csv: 66 rows, one per value of the live feed (66)
- holds: hfsize_outcomes.csv: 1 rows, the live feed holds 1 results, outcome, n, lo and hi equal on every row
- holds: page headline "9 of 120": 9 is in the pack
- holds: page headline "9 of 120": 120 is in the pack

TESTED 2026-11-24 11:16 UTC: 4 checks, every one holds.
