# HFSIZE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-19 04:12 UTC and checked against the live feed at https://indahl.ai/hfsize/live.json.

- holds: hfsize_summary.csv: 69 rows, one per value of the live feed (69)
- holds: hfsize_outcomes.csv: 1 rows, the live feed holds 1 results, outcome, n, lo and hi equal on every row
- holds: page headline "10 of 132": 10 is in the pack
- holds: page headline "10 of 132": 132 is in the pack

TESTED 2026-11-19 04:12 UTC: 4 checks, every one holds.
