# HFSIZE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-28 14:01 UTC and checked against the live feed at https://indahl.ai/hfsize/live.json.

- holds: hfsize_summary.csv: 60 rows, one per value of the live feed (60)
- holds: hfsize_outcomes.csv: 1 rows, the live feed holds 1 results, outcome, n, lo and hi equal on every row
- holds: page headline "9 of 118": 9 is in the pack
- holds: page headline "9 of 118": 118 is in the pack

TESTED 2026-11-28 14:01 UTC: 4 checks, every one holds.
