# HOSTS Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-21 15:48 UTC and checked against the live feed at https://indahl.ai/hosts/live.json.

- holds: hosts_summary.csv: 80 rows, one per value of the live feed (80)
- holds: hosts_outcomes.csv: 1 rows, the live feed holds 1 results, outcome, n, lo and hi equal on every row
- holds: page headline "21": 21 is in the pack

TESTED 2026-11-21 15:48 UTC: 3 checks, every one holds.
