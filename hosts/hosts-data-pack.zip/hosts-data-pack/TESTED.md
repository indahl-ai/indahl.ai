# HOSTS Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-25 16:49 UTC and checked against the live feed at https://indahl.ai/hosts/live.json.

- holds: hosts_summary.csv: 127 rows, one per value of the live feed (127)
- holds: hosts_outcomes.csv: 1 rows, the live feed holds 1 results, outcome, n, lo and hi equal on every row
- holds: page headline "78 of 181": 78 is in the pack
- holds: page headline "78 of 181": 181 is in the pack

TESTED 2026-11-25 16:49 UTC: 4 checks, every one holds.
