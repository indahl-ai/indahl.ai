# HOSTS Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-23 14:06 UTC and checked against the live feed at https://indahl.ai/hosts/live.json.

- holds: hosts_summary.csv: 113 rows, one per value of the live feed (113)
- holds: hosts_outcomes.csv: 1 rows, the live feed holds 1 results, outcome, n, lo and hi equal on every row
- holds: page headline "79 of 186": 79 is in the pack
- holds: page headline "79 of 186": 186 is in the pack

TESTED 2026-11-23 14:06 UTC: 4 checks, every one holds.
