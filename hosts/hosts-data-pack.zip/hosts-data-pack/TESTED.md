# HOSTS Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-25 03:03 UTC and checked against the live feed at https://indahl.ai/hosts/live.json.

- holds: hosts_summary.csv: 204 rows, one per value of the live feed (204)
- holds: hosts_outcomes.csv: 1 rows, the live feed holds 1 results, outcome, n, lo and hi equal on every row
- holds: page headline "76 of 181": 76 is in the pack
- holds: page headline "76 of 181": 181 is in the pack

TESTED 2026-11-25 03:03 UTC: 4 checks, every one holds.
