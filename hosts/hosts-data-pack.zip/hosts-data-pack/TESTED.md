# HOSTS Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-18 21:23 UTC and checked against the live feed at https://indahl.ai/hosts/live.json.

- holds: hosts_summary.csv: 134 rows, one per value of the live feed (134)
- holds: hosts_outcomes.csv: 1 rows, the live feed holds 1 results, outcome, n, lo and hi equal on every row
- holds: page headline "41": 41 is in the pack

TESTED 2026-11-18 21:23 UTC: 3 checks, every one holds.
