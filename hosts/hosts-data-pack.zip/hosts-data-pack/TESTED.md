# HOSTS Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-24 22:01 UTC and checked against the live feed at https://indahl.ai/hosts/live.json.

- holds: hosts_summary.csv: 125 rows, one per value of the live feed (125)
- holds: hosts_outcomes.csv: 1 rows, the live feed holds 1 results, outcome, n, lo and hi equal on every row
- holds: page headline "75 of 180": 75 is in the pack
- holds: page headline "75 of 180": 180 is in the pack

TESTED 2026-11-24 22:01 UTC: 4 checks, every one holds.
