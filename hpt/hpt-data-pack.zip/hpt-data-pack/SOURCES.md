# HPT Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 26 Nov 2026 15:41, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Hospital cms-hpt.txt files under the CMS price transparency rule | https://www.cms.gov/priorities/key-initiatives/hospital-price-transparency | public files published under a federal rule, presence and header facts only | 26 Nov 2026 15:41 |
| Wikidata (US hospitals with official websites) | https://query.wikidata.org/ | CC0 1.0 | 26 Nov 2026 15:41 |
