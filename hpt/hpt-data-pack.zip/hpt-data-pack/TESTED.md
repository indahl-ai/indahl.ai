# HPT Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-19 00:55 UTC and checked against the live feed at https://indahl.ai/hpt/live.json.

- holds: hpt_summary.csv: 128 rows, one per value of the live feed (128)
- holds: hpt_outcomes.csv: 3 rows, the live feed holds 3 results, outcome, n, lo and hi equal on every row
- holds: hpt_summary.json: byte for byte the live feed (sha256 97991e0a46bd8206)
- holds: page headline "10 of 454": 10 is in the pack
- holds: page headline "10 of 454": 454 is in the pack
- holds: rows.csv: 1925 rows, the live feed counts 1925
- holds: rows.csv: s1 counts {'NOT_COMPARABLE': 946, 'DISAGREE': 469, 'AGREE': 510} equal the live feed

TESTED 2026-11-19 00:55 UTC: 7 checks, every one holds.
