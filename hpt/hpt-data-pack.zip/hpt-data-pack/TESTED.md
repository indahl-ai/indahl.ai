# HPT Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-26 20:48 UTC and checked against the live feed at https://indahl.ai/hpt/live.json.

- holds: hpt_summary.csv: 127 rows, one per value of the live feed (127)
- holds: hpt_outcomes.csv: 3 rows, the live feed holds 3 results, outcome, n, lo and hi equal on every row
- holds: hpt_summary.json: byte for byte the live feed (sha256 73b8c914db691663)
- holds: page headline "519 of 1,019": 519 is in the pack
- holds: page headline "519 of 1,019": 1,019 is in the pack
- holds: rows.csv: 1925 rows, the live feed counts 1925
- holds: rows.csv: s1 counts {'NOT_COMPARABLE': 906, 'DISAGREE': 519, 'AGREE': 500} equal the live feed

TESTED 2026-11-26 20:48 UTC: 7 checks, every one holds.
