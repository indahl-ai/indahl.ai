# LAUNCH Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 23 Nov 2026 01:59, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Launch Library 2 | https://thespacedevs.com/llapi | The Space Devs terms, no data licence stated | 23 Nov 2026 01:59 |
