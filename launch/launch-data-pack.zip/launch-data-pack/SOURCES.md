# LAUNCH Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 26 Nov 2026 02:32, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Launch Library 2 | https://thespacedevs.com/llapi | The Space Devs terms, no data licence stated | 26 Nov 2026 02:32 |
