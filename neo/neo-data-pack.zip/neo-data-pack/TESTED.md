# NEO Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-24 13:48 UTC and checked against the live feed at https://indahl.ai/neo/live.json.

- holds: neo_summary.csv: 297 rows, one per value of the live feed (297)
- holds: neo_outcomes.csv: 58 rows, the live feed holds 58 results, outcome, n, lo and hi equal on every row
- holds: page headline "220 of 220": 220 is in the pack
- holds: page headline "220 of 220": 220 is in the pack

TESTED 2026-11-24 13:48 UTC: 4 checks, every one holds.
