# NEO Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-23 18:06 UTC and checked against the live feed at https://indahl.ai/neo/live.json.

- holds: neo_summary.csv: 296 rows, one per value of the live feed (296)
- holds: neo_outcomes.csv: 58 rows, the live feed holds 58 results, outcome, n, lo and hi equal on every row
- holds: page headline "219 of 219": 219 is in the pack
- holds: page headline "219 of 219": 219 is in the pack

TESTED 2026-11-23 18:06 UTC: 4 checks, every one holds.
