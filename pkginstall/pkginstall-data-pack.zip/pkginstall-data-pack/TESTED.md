# PKGINSTALL Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-23 16:13 UTC and checked against the live feed at https://indahl.ai/pkginstall/live.json.

- holds: pkginstall_summary.csv: 26 rows, one per value of the live feed (26)
- holds: pkginstall_outcomes.csv: 1 rows, the live feed holds 1 results, outcome, n, lo and hi equal on every row
- holds: page headline "524 of 525": 524 is in the pack
- holds: page headline "524 of 525": 525 is in the pack

TESTED 2026-11-23 16:13 UTC: 4 checks, every one holds.
