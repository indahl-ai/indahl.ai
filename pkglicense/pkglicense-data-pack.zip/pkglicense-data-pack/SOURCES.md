# PKGLICENSE Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 21 Nov 2026 15:56, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| PyPI JSON API | https://docs.pypi.org/api/json/ | PyPI terms of service | 21 Nov 2026 15:56 |
| Top PyPI Packages | https://hugovk.github.io/top-pypi-packages/ | public list | 21 Nov 2026 15:56 |
| GitHub GraphQL API licenseInfo | https://docs.github.com/en/graphql | GitHub terms of service | 21 Nov 2026 15:56 |
