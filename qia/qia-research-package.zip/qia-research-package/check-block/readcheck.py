#!/usr/bin/env python3
"""readcheck.py: the check block a reading carries before it enters a results file, a paper, a page or a public ledger.
Heuremen LLC, 30 Oct 2026. Spec: SPEC.md beside this file. Standard library only.
  readcheck.py new <folder> --packs L,P --what "<the reading>"   append a dated template entry to <folder>/CHECKS.md
  readcheck.py check <CHECKS.md>                                       exit 0 only if the LAST entry is complete
  readcheck.py check-staged <CHECKS.md>                                exit 0 only if the staged diff adds a complete entry (used by the hook)
A field is answered when its text starts with holds:, fixed:, caught:, n/a: or cannot tell: and carries at least 12 more characters.
Packs: L language-model evaluations, P public copy. The core fields are always required."""
import sys, os, re, datetime, subprocess
CORE = [('I', 'the none built first, like for like; what the gate drops, by arm'), ('II', 'gap: item flips counted against the repeat floor before any net'),
        ('III', 'sign: do the cells agree in sign; product or sum'), ('V', 'ruler named, two side by side where they can disagree'),
        ('VI', 'four outcomes, both alternatives (zero and the size that matters) tested'), ('R', 'counts, dates, versions read from the record; post hoc labelled'),
        ('X', 'the cause: if this corrects/replaces/withdraws an earlier reading, why it was wrong, why unseen, and the new gate/check/alert shipped with it; else "holds: no earlier reading"')]
# 21 Nov 2026: X (THE CAUSE) joined the core. Entries dated before X_FROM are checked without it, so committed blocks stay valid.
# The automated writers (desk make_rows.py, fidelity ledger_rows.py, ledger/downloads.py, ledger/zenodo_sync.py) carry an X line from the same change.
X_FROM = '2026-11-21 18:15'
PACKS = {'L': [('L1', 'parser read in full before any rate'), ('L2', 'no rate seen before the parser read'), ('L3', 'setup/harness/extraction named on both sides'),
               ('L4', 'repeat floor per machine; run-time server settings recorded'), ('L5', 'recount from released files, keys matched'),
               ('L6', 'unread/dropped counted by reason, per arm'), ('L7', 'gold not built from the labeller it scores'), ('L8', 'paired; seed width; position copy floor; batch'),
               ('L9', 'prompt does not contain the answer'), ('L10', 'pinned name is not pinned behaviour'), ('L11', 'aged datasets/tools substituted with counts and a note written first'),
               ('L12', 'same-family referee or labeller disclosed')],
         'P': [('P1', 'quotes verbatim'), ('P2', 'every figure says where it lives and which version'), ('P3', 'setting labels match the source'),
               ('P4', 'no cause where only a rule-out was measured'), ('P5', 'every interval says what it is'), ('P6', 'summary no stronger than the reading'),
               ('P7', 'source first, one release path, verified live'), ('P8', 'rendered page checked, scripts served'), ('P9', 'style rules written down and checked'), ('P10', 'post hoc labelled')]}
ANS = re.compile(r'^\s*-?\s*([A-Z]+\d*)\s*[:|]\s*(holds|fixed|caught|n/a|cannot tell)\s*:\s*(.{12,})$', re.I)
def entries(text):
    parts = re.split(r'(?m)^## (?=\d{4}-\d{2}-\d{2})', text); return [p for p in parts[1:]]
def missing(entry):
    m = re.search(r'(?m)^packs:\s*([A-Z,\s]*)$', entry); packs = [x.strip() for x in (m.group(1) if m else '').split(',') if x.strip()]
    dated = re.match(r'\s*(\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2})?)', entry); old = bool(dated) and dated.group(1) < X_FROM
    need = [k for k, _ in CORE if not (old and k == 'X')] +[k for p in packs for k, _ in PACKS.get(p, [])]
    got = {m.group(1).upper() for m in (ANS.match(l) for l in entry.splitlines()) if m}
    return [k for k in need if k.upper() not in got], packs
def new(folder, packs, what):
    p = os.path.join(folder, 'CHECKS.md'); d = datetime.datetime.now().strftime('%Y-%m-%d %H:%M')
    L = [f'## {d} {what}', f'packs: {",".join(packs)}', '(answer each line: holds:/fixed:/caught:/n/a:/cannot tell: followed by what was checked)']
    L += [f'- {k}: TODO ({desc})' for k, desc in CORE] + [f'- {k}: TODO ({desc})' for pk in packs for k, desc in PACKS[pk]]
    open(p, 'a').write(('\n' if os.path.exists(p) else '# Check blocks (readcheck.py). One entry per reading, appended, never edited after commit.\n\n') + '\n'.join(L) + '\n')
    print('appended a template entry to', p)
def check_text(text, src):
    es = entries(text)
    if not es: print(f'REFUSED {src}: no dated entry'); return 1
    miss, packs = missing(es[-1])
    if miss: print(f'REFUSED {src}: last entry leaves unanswered: ' + ', '.join(miss)); return 1
    print(f'ok {src}: last entry complete (core + packs {",".join(packs) or "none"})'); return 0
if __name__ == '__main__':
    a = sys.argv[1:]
    if a and a[0] == 'new':
        packs = a[a.index('--packs') + 1].split(',') if '--packs' in a else []; what = a[a.index('--what') + 1] if '--what' in a else ''
        bad = [p for p in packs if p not in PACKS]
        if bad: sys.exit('unknown pack: ' + ','.join(bad))
        new(a[1], packs, what)
    elif a and a[0] == 'check': sys.exit(check_text(open(a[1]).read(), a[1]))
    elif a and a[0] == 'check-staged':
        f = a[1]; added = subprocess.run(['git', 'diff', '--cached', '-U0', '--', f], capture_output=True, text=True).stdout
        text = '\n'.join(l[1:] for l in added.splitlines() if l.startswith('+') and not l.startswith('+++'))
        sys.exit(check_text(text, f + ' (staged additions)'))
    else: print(__doc__); sys.exit(2)
