# YO

Heuremen LLC. YO reads an IBM calibration record and flags stale and zero entries. The exact answer computed by code is printed beside it.



```
gh release download yo-v7 --repo indahl-ai/indahl.ai --dir yo-v7   # the weights, Apache-2.0
pip install mlx-lm            # Apple silicon
python yo_audit.py record.json --model yo-v7

pip install transformers torch  # elsewhere
python yo_audit.py record.json --fused yo-v7
```

Every result: https://indahl.ai/iris/lab
