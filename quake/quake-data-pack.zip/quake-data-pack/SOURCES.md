# QUAKE Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 2026-11-25T15:51:59Z, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| USGS ComCat event service, aftershock forecast product (oaf) and catalog | https://earthquake.usgs.gov/fdsnws/event/1/ | U.S. government work, public domain (17 U.S.C. 105) | 2026-11-25T15:51:59Z |
| USGS aftershock forecast documentation | https://earthquake.usgs.gov/data/oaf/overview.php | U.S. government work, public domain (17 U.S.C. 105) | 2026-11-25T15:51:59Z |
