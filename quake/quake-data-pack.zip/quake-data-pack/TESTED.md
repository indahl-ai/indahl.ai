# QUAKE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-24 06:48 UTC and checked against the live feed at https://indahl.ai/quake/live.json.

- holds: quake_summary.csv: 4062 rows, one per value of the live feed (4062)
- holds: quake_outcomes.csv: 87 rows, the live feed holds 87 results, outcome, n, lo and hi equal on every row
- holds: quake_summary.json: byte for byte the live feed (sha256 ebbac7edd58ef700)
- holds: page headline "30.2%": 30.2% is in the pack

TESTED 2026-11-24 06:48 UTC: 4 checks, every one holds.
