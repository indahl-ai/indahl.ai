# QUAKE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-21 12:35 UTC and checked against the live feed at https://indahl.ai/quake/live.json.

- holds: quake_summary.csv: 4082 rows, one per value of the live feed (4082)
- holds: quake_outcomes.csv: 87 rows, the live feed holds 87 results, outcome, n, lo and hi equal on every row
- holds: quake_summary.json: byte for byte the live feed (sha256 cb4f202832584031)
- holds: page headline "29,980 of 31,119": 29,980 is in the pack
- holds: page headline "29,980 of 31,119": 31,119 is in the pack

TESTED 2026-11-21 12:35 UTC: 5 checks, every one holds.
