# QUAKE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-27 16:00 UTC and checked against the live feed at https://indahl.ai/quake/live.json.

- holds: quake_summary.csv: 4022 rows, one per value of the live feed (4022)
- holds: quake_outcomes.csv: 87 rows, the live feed holds 87 results, outcome, n, lo and hi equal on every row
- holds: quake_summary.json: byte for byte the live feed (sha256 2e5989e2023df662)
- holds: page headline "29.8%": 29.8% is in the pack

TESTED 2026-11-27 16:00 UTC: 4 checks, every one holds.
