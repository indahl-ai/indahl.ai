# QUAKE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-19 10:40 UTC and checked against the live feed at https://indahl.ai/quake/live.json.

- holds: quake_summary.csv: 4102 rows, one per value of the live feed (4102)
- holds: quake_outcomes.csv: 87 rows, the live feed holds 87 results, outcome, n, lo and hi equal on every row
- holds: quake_summary.json: byte for byte the live feed (sha256 19b4c1041f42a25a)
- holds: page headline "30,366 of 31,583": 30,366 is in the pack
- holds: page headline "30,366 of 31,583": 31,583 is in the pack

TESTED 2026-11-19 10:40 UTC: 5 checks, every one holds.
