# QUAKE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-24 13:48 UTC and checked against the live feed at https://indahl.ai/quake/live.json.

- holds: quake_summary.csv: 4052 rows, one per value of the live feed (4052)
- holds: quake_outcomes.csv: 87 rows, the live feed holds 87 results, outcome, n, lo and hi equal on every row
- holds: quake_summary.json: byte for byte the live feed (sha256 66723ce703528ad5)
- holds: page headline "30.1%": 30.1% is in the pack

TESTED 2026-11-24 13:48 UTC: 4 checks, every one holds.
