# QUAKE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-21 10:19 UTC and checked against the live feed at https://indahl.ai/quake/live.json.

- holds: quake_summary.csv: 4082 rows, one per value of the live feed (4082)
- holds: quake_outcomes.csv: 87 rows, the live feed holds 87 results, outcome, n, lo and hi equal on every row
- holds: quake_summary.json: byte for byte the live feed (sha256 2f744036538585ed)
- holds: page headline "29,968 of 31,107": 29,968 is in the pack
- holds: page headline "29,968 of 31,107": 31,107 is in the pack

TESTED 2026-11-21 10:19 UTC: 5 checks, every one holds.
