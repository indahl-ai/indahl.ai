# QUAKE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-22 19:41 UTC and checked against the live feed at https://indahl.ai/quake/live.json.

- holds: quake_summary.csv: 4072 rows, one per value of the live feed (4072)
- holds: quake_outcomes.csv: 87 rows, the live feed holds 87 results, outcome, n, lo and hi equal on every row
- holds: quake_summary.json: byte for byte the live feed (sha256 7b339ac8710ac21d)
- holds: page headline "30.2%": 30.2% is in the pack

TESTED 2026-11-22 19:41 UTC: 4 checks, every one holds.
