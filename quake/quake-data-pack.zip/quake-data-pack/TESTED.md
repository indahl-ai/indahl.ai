# QUAKE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-19 17:16 UTC and checked against the live feed at https://indahl.ai/quake/live.json.

- holds: quake_summary.csv: 4102 rows, one per value of the live feed (4102)
- holds: quake_outcomes.csv: 87 rows, the live feed holds 87 results, outcome, n, lo and hi equal on every row
- holds: quake_summary.json: byte for byte the live feed (sha256 e1fa7ecac0007a98)
- holds: page headline "30,395 of 31,614": 30,395 is in the pack
- holds: page headline "30,395 of 31,614": 31,614 is in the pack

TESTED 2026-11-19 17:16 UTC: 5 checks, every one holds.
