# QUAKE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-26 02:11 UTC and checked against the live feed at https://indahl.ai/quake/live.json.

- holds: quake_summary.csv: 4032 rows, one per value of the live feed (4032)
- holds: quake_outcomes.csv: 87 rows, the live feed holds 87 results, outcome, n, lo and hi equal on every row
- holds: quake_summary.json: byte for byte the live feed (sha256 14d2b883fd70ac57)
- holds: page headline "30.0%": 30.0% is in the pack

TESTED 2026-11-26 02:11 UTC: 4 checks, every one holds.
