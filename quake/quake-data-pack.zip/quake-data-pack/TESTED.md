# QUAKE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-18 21:23 UTC and checked against the live feed at https://indahl.ai/quake/live.json.

- holds: quake_summary.csv: 4072 rows, one per value of the live feed (4072)
- holds: quake_outcomes.csv: 87 rows, the live feed holds 87 results, outcome, n, lo and hi equal on every row
- holds: quake_summary.json: byte for byte the live feed (sha256 ffdb50bcc9f872cd)
- holds: page headline "30,332 of 31,547": 30,332 is in the pack
- holds: page headline "30,332 of 31,547": 31,547 is in the pack

TESTED 2026-11-18 21:23 UTC: 5 checks, every one holds.
