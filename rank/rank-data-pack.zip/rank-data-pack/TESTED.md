# RANK Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-23 22:17 UTC and checked against the live feed at https://indahl.ai/rank/live.json.

- holds: rank_summary.csv: 1666 rows, one per value of the live feed (1666)
- holds: rank_outcomes.csv: 787 rows, the live feed holds 787 results, outcome, n, lo and hi equal on every row
- holds: page headline "2 of 217": 2 is in the pack
- holds: page headline "2 of 217": 217 is in the pack

TESTED 2026-11-23 22:17 UTC: 4 checks, every one holds.
