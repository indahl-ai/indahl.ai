# REVISE Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 25 Nov 2026 15:52, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| BLS Current Employment Statistics, nonfarm payroll revisions | https://www.bls.gov/ces/ | U.S. government work, public domain (17 U.S.C. 105) | 25 Nov 2026 15:52 |
