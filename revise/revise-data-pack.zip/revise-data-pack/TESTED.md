# REVISE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-23 11:30 UTC and checked against the live feed at https://indahl.ai/revise/live.json.

- holds: revise_summary.csv: 94 rows, one per value of the live feed (94)
- holds: revise_outcomes.csv: 2 rows, the live feed holds 2 results, outcome, n, lo and hi equal on every row
- holds: revise_summary.json: byte for byte the live feed (sha256 bf2987928e6da1fa)
- holds: page headline "25 of 120": 25 is in the pack
- holds: page headline "25 of 120": 120 is in the pack

TESTED 2026-11-23 11:30 UTC: 5 checks, every one holds.
