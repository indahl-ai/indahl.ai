# SEAT Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-27 18:05 UTC and checked against the live feed at https://indahl.ai/seat/live.json.

- holds: seat_summary.csv: 256 rows, one per value of the live feed (256)
- holds: seat_outcomes.csv: 1 rows, the live feed holds 1 results, outcome, n, lo and hi equal on every row
- holds: seat_summary.json: byte for byte the live feed (sha256 a5e66b7db1aa8db3)

TESTED 2026-11-27 18:05 UTC: 3 checks, every one holds.
