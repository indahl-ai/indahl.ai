# SEAT Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-21 18:10 UTC and checked against the live feed at https://indahl.ai/seat/live.json.

- holds: seat_summary.csv: 255 rows, one per value of the live feed (255)
- holds: seat_outcomes.csv: 1 rows, the live feed holds 1 results, outcome, n, lo and hi equal on every row
- holds: seat_summary.json: byte for byte the live feed (sha256 a142aec3164803bf)

TESTED 2026-11-21 18:10 UTC: 3 checks, every one holds.
