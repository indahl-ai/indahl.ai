# SEAT Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-21 02:45 UTC and checked against the live feed at https://indahl.ai/seat/live.json.

- holds: seat_summary.csv: 295 rows, one per value of the live feed (295)
- holds: seat_outcomes.csv: 1 rows, the live feed holds 1 results, outcome, n, lo and hi equal on every row
- holds: seat_summary.json: byte for byte the live feed (sha256 6ec8baec2057d466)

TESTED 2026-11-21 02:45 UTC: 3 checks, every one holds.
