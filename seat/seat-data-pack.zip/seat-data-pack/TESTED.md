# SEAT Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-24 11:16 UTC and checked against the live feed at https://indahl.ai/seat/live.json.

- holds: seat_summary.csv: 256 rows, one per value of the live feed (256)
- holds: seat_outcomes.csv: 1 rows, the live feed holds 1 results, outcome, n, lo and hi equal on every row
- holds: seat_summary.json: byte for byte the live feed (sha256 896da3f4e908b35f)

TESTED 2026-11-24 11:16 UTC: 3 checks, every one holds.
