# SECRECORDS Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 22 Nov 2026 19:17, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Tranco list | https://tranco-list.eu/ | Tranco terms, built from inputs that include CC BY-NC and share-alike data | 22 Nov 2026 19:17 |
| HTTPS headers and DNS records of each domain | https://indahl.ai/secrecords | public protocol facts, our own reads | 22 Nov 2026 19:17 |
