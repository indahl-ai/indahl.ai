# SOLAR Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-26 10:48 UTC and checked against the live feed at https://indahl.ai/solar/live.json.

- holds: solar_summary.csv: 3602 rows, one per value of the live feed (3602)
- holds: solar_outcomes.csv: 280 rows, the live feed holds 280 results, outcome, n, lo and hi equal on every row
- holds: solar_summary.json: byte for byte the live feed (sha256 e6c1489e4a964acb)
- holds: page headline "4 of 8": 4 is in the pack
- holds: page headline "4 of 8": 8 is in the pack

TESTED 2026-11-26 10:48 UTC: 5 checks, every one holds.
