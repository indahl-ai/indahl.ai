# STACK Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-20 00:18 UTC and checked against the live feed at https://indahl.ai/stack/live.json.

- holds: stack_summary.csv: 686 rows, one per value of the live feed (686)
- holds: stack_outcomes.csv: 54 rows, the live feed holds 54 results, outcome, n, lo and hi equal on every row
- holds: stack_summary.json: byte for byte the live feed (sha256 d74e2f409cf0a41c)

TESTED 2026-11-20 00:18 UTC: 3 checks, every one holds.
