# SUPPORT Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 19 Nov 2026 09:41, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| endoflife.date API | https://endoflife.date/docs/api | endoflife.date terms | 19 Nov 2026 09:41 |
