# SUPPORT Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 27 Nov 2026 14:02, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| endoflife.date API | https://endoflife.date/docs/api | endoflife.date terms | 27 Nov 2026 14:02 |
