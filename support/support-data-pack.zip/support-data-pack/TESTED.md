# SUPPORT Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-21 12:35 UTC and checked against the live feed at https://indahl.ai/support/live.json.

- holds: support_summary.csv: 665 rows, one per value of the live feed (665)
- holds: support_outcomes.csv: 46 rows, the live feed holds 46 results, outcome, n, lo and hi equal on every row
- holds: page headline "24%": 24% is in the pack

TESTED 2026-11-21 12:35 UTC: 3 checks, every one holds.
