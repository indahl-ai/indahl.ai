# SUPPORT Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-26 14:05 UTC and checked against the live feed at https://indahl.ai/support/live.json.

- holds: support_summary.csv: 685 rows, one per value of the live feed (685)
- holds: support_outcomes.csv: 48 rows, the live feed holds 48 results, outcome, n, lo and hi equal on every row
- holds: page headline "25%": 25% is in the pack

TESTED 2026-11-26 14:05 UTC: 3 checks, every one holds.
