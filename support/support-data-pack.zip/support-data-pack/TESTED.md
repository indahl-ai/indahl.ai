# SUPPORT Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-23 04:33 UTC and checked against the live feed at https://indahl.ai/support/live.json.

- holds: support_summary.csv: 675 rows, one per value of the live feed (675)
- holds: support_outcomes.csv: 47 rows, the live feed holds 47 results, outcome, n, lo and hi equal on every row
- holds: page headline "25%": 25% is in the pack

TESTED 2026-11-23 04:33 UTC: 3 checks, every one holds.
