# TAPE Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 21 Nov 2026 14:30, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Our own hash chain of pages and feeds | https://indahl.ai/tape | Heuremen LLC | 21 Nov 2026 14:30 |
| drand randomness beacon | https://drand.love/ | public beacon | 21 Nov 2026 14:30 |
