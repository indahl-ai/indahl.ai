# TAPE Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 22 Nov 2026 22:39, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Our own hash chain of pages and feeds | https://indahl.ai/tape | Heuremen LLC | 22 Nov 2026 22:39 |
| drand randomness beacon | https://drand.love/ | public beacon | 22 Nov 2026 22:39 |
