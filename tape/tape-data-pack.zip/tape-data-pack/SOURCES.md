# TAPE Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 23 Nov 2026 12:20, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Our own hash chain of pages and feeds | https://indahl.ai/tape | Heuremen LLC | 23 Nov 2026 12:20 |
| drand randomness beacon | https://drand.love/ | public beacon | 23 Nov 2026 12:20 |
