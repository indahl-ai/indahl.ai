# TAPE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-23 03:37 UTC and checked against the live feed at https://indahl.ai/tape/live.json.

- holds: tape_summary.csv: 5396 rows, one per value of the live feed (5396)
- holds: tape_outcomes.csv: 0 rows, the live feed holds 0 results, outcome, n, lo and hi equal on every row
- holds: tape_summary.json: byte for byte the live feed (sha256 d5d97eff7d6017a1)
- holds: page headline "78 s": 78 is a clock reading at page load, not a number in the feed

TESTED 2026-11-23 03:37 UTC: 4 checks, every one holds.
