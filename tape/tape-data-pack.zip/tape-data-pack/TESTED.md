# TAPE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-28 14:11 UTC and checked against the live feed at https://indahl.ai/tape/live.json.

- holds: tape_summary.csv: 5401 rows, one per value of the live feed (5401)
- holds: tape_outcomes.csv: 0 rows, the live feed holds 0 results, outcome, n, lo and hi equal on every row
- holds: tape_summary.json: byte for byte the live feed (sha256 e69ac129ff9fe5e2)
- holds: page headline "3 min": 3 is a clock reading at page load, not a number in the feed

TESTED 2026-11-28 14:11 UTC: 4 checks, every one holds.
