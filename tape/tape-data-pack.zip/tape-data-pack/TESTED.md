# TAPE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-20 00:57 UTC and checked against the live feed at https://indahl.ai/tape/live.json.

- holds: tape_summary.csv: 5015 rows, one per value of the live feed (5015)
- holds: tape_outcomes.csv: 0 rows, the live feed holds 0 results, outcome, n, lo and hi equal on every row
- holds: tape_summary.json: byte for byte the live feed (sha256 c2c332c987f36346)
- holds: page headline "25 s": 25 is a clock reading at page load, not a number in the feed

TESTED 2026-11-20 00:57 UTC: 4 checks, every one holds.
