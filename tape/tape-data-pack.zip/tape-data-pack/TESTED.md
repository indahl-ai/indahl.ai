# TAPE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-24 21:16 UTC and checked against the live feed at https://indahl.ai/tape/live.json.

- holds: tape_summary.csv: 5420 rows, one per value of the live feed (5420)
- holds: tape_outcomes.csv: 0 rows, the live feed holds 0 results, outcome, n, lo and hi equal on every row
- holds: tape_summary.json: byte for byte the live feed (sha256 5e0457bef809f38d)
- holds: page headline "8 min": 8 is a clock reading at page load, not a number in the feed

TESTED 2026-11-24 21:16 UTC: 4 checks, every one holds.
