# TAPE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-26 20:49 UTC and checked against the live feed at https://indahl.ai/tape/live.json.

- holds: tape_summary.csv: 5407 rows, one per value of the live feed (5407)
- holds: tape_outcomes.csv: 0 rows, the live feed holds 0 results, outcome, n, lo and hi equal on every row
- holds: tape_summary.json: byte for byte the live feed (sha256 dc3940ac5b128e45)
- holds: page headline "4 min": 4 is a clock reading at page load, not a number in the feed

TESTED 2026-11-26 20:49 UTC: 4 checks, every one holds.
