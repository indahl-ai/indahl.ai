# TAPE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-23 00:58 UTC and checked against the live feed at https://indahl.ai/tape/live.json.

- holds: tape_summary.csv: 5376 rows, one per value of the live feed (5376)
- holds: tape_outcomes.csv: 0 rows, the live feed holds 0 results, outcome, n, lo and hi equal on every row
- holds: tape_summary.json: byte for byte the live feed (sha256 a4785fadd05d3d42)
- holds: page headline "3 min": 3 is a clock reading at page load, not a number in the feed

TESTED 2026-11-23 00:58 UTC: 4 checks, every one holds.
