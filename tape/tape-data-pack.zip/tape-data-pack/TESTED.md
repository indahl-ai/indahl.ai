# TAPE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-23 11:30 UTC and checked against the live feed at https://indahl.ai/tape/live.json.

- holds: tape_summary.csv: 5358 rows, one per value of the live feed (5358)
- holds: tape_outcomes.csv: 0 rows, the live feed holds 0 results, outcome, n, lo and hi equal on every row
- holds: tape_summary.json: byte for byte the live feed (sha256 9a236ed4e0bee7c8)
- holds: page headline "64 s": 64 is a clock reading at page load, not a number in the feed

TESTED 2026-11-23 11:30 UTC: 4 checks, every one holds.
