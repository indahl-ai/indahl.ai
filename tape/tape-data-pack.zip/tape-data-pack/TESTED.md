# TAPE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-19 10:40 UTC and checked against the live feed at https://indahl.ai/tape/live.json.

- holds: tape_summary.csv: 4927 rows, one per value of the live feed (4927)
- holds: tape_outcomes.csv: 0 rows, the live feed holds 0 results, outcome, n, lo and hi equal on every row
- holds: tape_summary.json: byte for byte the live feed (sha256 1d79b61442c610f8)
- holds: page headline "20 s": 20 is a clock reading at page load, not a number in the feed

TESTED 2026-11-19 10:40 UTC: 4 checks, every one holds.
