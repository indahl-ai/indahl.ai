# TAPE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-22 20:32 UTC and checked against the live feed at https://indahl.ai/tape/live.json.

- holds: tape_summary.csv: 5403 rows, one per value of the live feed (5403)
- holds: tape_outcomes.csv: 0 rows, the live feed holds 0 results, outcome, n, lo and hi equal on every row
- holds: tape_summary.json: byte for byte the live feed (sha256 ae56038e93aa7eb9)
- holds: page headline "82 s": 82 is a clock reading at page load, not a number in the feed

TESTED 2026-11-22 20:32 UTC: 4 checks, every one holds.
