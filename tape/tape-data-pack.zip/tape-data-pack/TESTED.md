# TAPE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-21 02:53 UTC and checked against the live feed at https://indahl.ai/tape/live.json.

- holds: tape_summary.csv: 5167 rows, one per value of the live feed (5167)
- holds: tape_outcomes.csv: 0 rows, the live feed holds 0 results, outcome, n, lo and hi equal on every row
- holds: tape_summary.json: byte for byte the live feed (sha256 a004b21ab9af4f51)
- holds: page headline "2 min": 2 is a clock reading at page load, not a number in the feed

TESTED 2026-11-21 02:53 UTC: 4 checks, every one holds.
