# TIME Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-20 20:42 UTC and checked against the live feed at https://indahl.ai/time/live.json.

- holds: time_summary.csv: 1001 rows, one per value of the live feed (1001)
- holds: time_outcomes.csv: 34 rows, the live feed holds 34 results, outcome, n, lo and hi equal on every row
- holds: time_summary.json: byte for byte the live feed (sha256 043e9f2e302e9bc7)

TESTED 2026-11-20 20:42 UTC: 3 checks, every one holds.
