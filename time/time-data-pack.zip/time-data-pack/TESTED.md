# TIME Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-23 20:22 UTC and checked against the live feed at https://indahl.ai/time/live.json.

- holds: time_summary.csv: 1004 rows, one per value of the live feed (1004)
- holds: time_outcomes.csv: 34 rows, the live feed holds 34 results, outcome, n, lo and hi equal on every row
- holds: time_summary.json: byte for byte the live feed (sha256 c67f4b4854318d41)

TESTED 2026-11-23 20:22 UTC: 3 checks, every one holds.
