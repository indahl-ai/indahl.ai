# TIME Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-27 16:58 UTC and checked against the live feed at https://indahl.ai/time/live.json.

- holds: time_summary.csv: 999 rows, one per value of the live feed (999)
- holds: time_outcomes.csv: 34 rows, the live feed holds 34 results, outcome, n, lo and hi equal on every row
- holds: time_summary.json: byte for byte the live feed (sha256 4cb4c051238fd030)

TESTED 2026-11-27 16:58 UTC: 3 checks, every one holds.
