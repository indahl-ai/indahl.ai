# UPTIME Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 27 Nov 2026 03:46, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Vendor status pages (Statuspage JSON) | https://indahl.ai/uptime | each vendor keeps its rights | 27 Nov 2026 03:46 |
| HTTPS probes from our seats | https://indahl.ai/uptime | our own measurements | 27 Nov 2026 03:46 |
