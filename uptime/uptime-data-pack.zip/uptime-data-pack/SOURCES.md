# UPTIME Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 19 Nov 2026 10:39, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Vendor status pages (Statuspage JSON) | https://indahl.ai/uptime | each vendor keeps its rights | 19 Nov 2026 10:39 |
| HTTPS probes from our seats | https://indahl.ai/uptime | our own measurements | 19 Nov 2026 10:39 |
