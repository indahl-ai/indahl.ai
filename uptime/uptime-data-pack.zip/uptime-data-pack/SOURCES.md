# UPTIME Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 21 Nov 2026 12:47, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Vendor status pages (Statuspage JSON) | https://indahl.ai/uptime | each vendor keeps its rights | 21 Nov 2026 12:47 |
| HTTPS probes from our seats | https://indahl.ai/uptime | our own measurements | 21 Nov 2026 12:47 |
