# WATER Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-21 16:46 UTC and checked against the live feed at https://indahl.ai/water/live.json.

- holds: water_summary.csv: 7760 rows, one per value of the live feed (7760)
- holds: water_outcomes.csv: 495 rows, the live feed holds 495 results, outcome, n, lo and hi equal on every row
- holds: water_summary.json: byte for byte the live feed (sha256 923f34c42827f07c)
- holds: page headline "42 of 83": 42 is in the pack
- holds: page headline "42 of 83": 83 is in the pack
- holds: rows.csv: 15270 rows, the live feed counts 15270

TESTED 2026-11-21 16:46 UTC: 6 checks, every one holds.
