# WEIGHTS Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-24 19:49 UTC and checked against the live feed at https://indahl.ai/weights/live.json.

- holds: weights_summary.csv: 1501 rows, one per value of the live feed (1501)
- holds: weights_outcomes.csv: 2 rows, the live feed holds 2 results, outcome, n, lo and hi equal on every row
- holds: page headline "31 of 1,130": 31 is in the pack
- holds: page headline "31 of 1,130": 1,130 is in the pack

TESTED 2026-11-24 19:49 UTC: 4 checks, every one holds.
