# WIKI Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-25 02:49 UTC and checked against the live feed at https://indahl.ai/wiki/live.json.

- holds: wiki_summary.csv: 8415 rows, one per value of the live feed (8415)
- holds: wiki_outcomes.csv: 359 rows, the live feed holds 359 results, outcome, n, lo and hi equal on every row
- holds: wiki_summary.json: byte for byte the live feed (sha256 623a55a23f60a199)

TESTED 2026-11-25 02:49 UTC: 3 checks, every one holds.
